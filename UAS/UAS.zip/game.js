const canvas = document.getElementById('glCanvas');
const gl = canvas.getContext('webgl');

const vertexShaderSource = `
  attribute vec2 aVertexPosition;

  void main() {
    gl_Position = vec4(aVertexPosition, 0.0, 1.0);
  }
`;

const fragmentShaderSource = `
  precision mediump float;

  uniform vec4 uColor;

  void main() {
    gl_FragColor = uColor;
  }
`;

const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
const shaderProgram = createProgram(gl, vertexShader, fragmentShader);

const paddle = { x: 0, y: -0.9, width: 0.2, height: 0.04, color: [1.0, 1.0, 0.0, 1.0] };
const ball = { x: 0, y: -0.8, radius: 0.02, color: [1.0, 0.0, 0.0, 1.0] };
const bricks = [];

let paddleX = 0;
let ballX = 0, ballY = -0.8, ballDX = 0.01, ballDY = 0.01;
let score = 0;
let gameOver = false;

function createShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  return shader;
}

function createProgram(gl, vertexShader, fragmentShader) {
  const program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  return program;
}

function drawRect(x, y, width, height, color) {
  gl.uniform4fv(shaderProgram.uColor, color);

  const x1 = x - width / 2;
  const x2 = x + width / 2;
  const y1 = y - height / 2;
  const y2 = y + height / 2;

  const vertices = [
    x1, y1,
    x2, y1,
    x1, y2,
    x1, y2,
    x2, y1,
    x2, y2,
  ];

  const vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

  const aVertexPosition = gl.getAttribLocation(shaderProgram, 'aVertexPosition');
  gl.vertexAttribPointer(aVertexPosition, 2, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(aVertexPosition);

  gl.drawArrays(gl.TRIANGLES, 0, 6);
}

function drawCircle(x, y, radius, color) {
  gl.uniform4fv(shaderProgram.uColor, color);

  const segments = 32;
  const vertices = [];

  for (let i = 0; i <= segments; i++) {
    const theta = (i * 2 * Math.PI) / segments;
    const x1 = x + radius * Math.cos(theta);
    const y1 = y + radius * Math.sin(theta);
    vertices.push(x1, y1);
  }

  const vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

  const aVertexPosition = gl.getAttribLocation(shaderProgram, 'aVertexPosition');
  gl.vertexAttribPointer(aVertexPosition, 2, gl.FLOAT, false, 0, 0);
  gl.enableVertexAttribArray(aVertexPosition);

  gl.drawArrays(gl.TRIANGLE_FAN, 0, segments + 1);
}

function render() {
  gl.clear(gl.COLOR_BUFFER_BIT);

  // Draw paddle
  drawRect(paddleX, paddle.y, paddle.width, paddle.height, paddle.color);

  // Draw ball
  drawCircle(ballX, ballY, ball.radius, ball.color);

  // Draw bricks
  for (let i = bricks.length - 1; i >= 0; i--) {
    const brick = bricks[i];
    drawRect(brick.x, brick.y, brick.width, brick.height, brick.color);

    if (
        ballX + ball.radius > brick.x - brick.width / 2 &&
        ballX - ball.radius < brick.x + brick.width / 2 &&
        ballY + ball.radius > brick.y - brick.height / 2 &&
        ballY - ball.radius < brick.y + brick.height / 2
      ) {
        ballDY = -ballDY;
        bricks.splice(i, 1); 
        score++;
      }
    }

  ballX += ballDX;
  ballY += ballDY;

  if (ballX - ball.radius < -1 || ballX + ball.radius > 1) {
    ballDX = -ballDX;
  }
  if (ballY + ball.radius > 1) {
    ballDY = -ballDY;
  }
  if (ballY - ball.radius < -1) {
    gameOver = true;
  }

  if (
    ballY - ball.radius <= paddle.y + paddle.height / 2 &&
    ballY - ball.radius >= paddle.y - paddle.height / 2 &&
    ballX + ball.radius >= paddleX - paddle.width / 2 &&
    ballX - ball.radius <= paddleX + paddle.width / 2
  ) {
    ballDY = -ballDY; 
  }

  if (gameOver || bricks.length === 0) {
    alert(`Game Over! Your score: ${score}`);
    resetGame();
  }

  requestAnimationFrame(render);
}

function resetGame() {
  score = 0;
  gameOver = false;
  ballX = 0;
  ballY = -0.8;
  ballDX = 0.01;
  ballDY = 0.01;
  bricks.length = 0;

  for (let i = 0; i < 5; i++) {
    for (let j = 0; j < 10; j++) {
      const x = -0.9 + j * 0.2;
      const y = 0.9 - i * 0.1;
      const width = 0.18;
      const height = 0.08;
      const color = [1.0, 0.0, 1.0, 1.0];
      bricks.push({ x, y, width, height, color });
    }
  }
}

function init() {
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.useProgram(shaderProgram);
  
    resetGame();
  
    render();
  }
  
  document.addEventListener('mousemove', (event) => {
    const rect = canvas.getBoundingClientRect();
    paddleX = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    paddleX = Math.max(-1 + paddle.width / 2, Math.min(1 - paddle.width / 2, paddleX));
  });
  
  init();