Progres 1 : Menambahkan object yang akan dijadikan dinosaurus dan memastikan input spacebar berjalan dengan benar
Progres 2 : Memastikan Dino dapat melompat dan bergerak 
Progress 3 : menambahkan collision dan gameover fuction ke dalam game
